import '../styles/globals.scss'
import React from 'react'
import { ChakraProvider } from '@chakra-ui/react'
import { AuthProvider } from "../authContext";
import { ApolloClient, ApolloProvider, InMemoryCache } from '@apollo/client'

const apollo = new ApolloClient({
  uri: 'http://localhost:13/7',
  cache: new InMemoryCache()
})

function MyApp({ Component, pageProps }) {
  return (
    <ApolloProvider client={apollo}>
      <AuthProvider>
        <ChakraProvider>
          <Component {...pageProps} />
        </ChakraProvider>
      </AuthProvider>
    </ApolloProvider>
  )
}

export default MyApp
