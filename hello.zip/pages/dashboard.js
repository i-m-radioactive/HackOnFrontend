import React from 'react'
import Layout from '../components/Layout'

import {
  FormControl,
  FormLabel,
  FormErrorMessage,
  FormHelperText,
  Input,
  RadioGroup,
  HStack,
  Radio,
  Select
} from "@chakra-ui/react"
import Dashboard from '../components/Dashboard'



const dashboard = () => {
  return (
    <Layout>
      <Dashboard />
    </Layout>
  )
}

export async function getServerSideProps(context) {

  if (context.req.cookies.token == "") {
    return {
      redirect: {
        destination: '/login',
        permanent: false
      }
    }
  }

  return {
    props: {}
  }

}

export default dashboard;
