import React from 'react'
import styleViewPost from '../styles/viewpost.module.scss'
const ViewPost = () => {
    return (
        <div className={styleViewPost.viewpost}>
            <div className={styleViewPost.container}></div>
            <div className={styleViewPost.container}></div>
            <div className={styleViewPost.container}></div>
            <div className={styleViewPost.container}></div>
            <div className={styleViewPost.container}></div>
            <div className={styleViewPost.container}></div>
        </div>
    )
}

export default ViewPost
