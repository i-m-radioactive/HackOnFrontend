import React, { useState, useEffect } from 'react'
import styleLogin from '../styles/login.module.scss'
import { Button, ButtonGroup } from "@chakra-ui/react"
import styleDashboard from '../styles/dashboard.module.scss'
import ViewRequest from '../components/ViewRequest'
import ViewPost from '../components/ViewPost'
import ManageProfile from '../components/ManageProfile'


import {
    FormControl,
    FormLabel,
    FormErrorMessage,
    FormHelperText,
    Input,
    RadioGroup,
    HStack,
    Radio,
    Select
} from "@chakra-ui/react"

const Dashboard = () => {
    const [view, setView] = useState("CR");

    useEffect(() => {
        if (window.localStorage.getItem("view")) {
            setView(window.localStorage.getItem("view"))
        }

    }, [])

    const saveView = () => {
        console.log(view);
        localStorage.setItem("view", view);
    }

    let xyz = "null";
    if (view == "CR") {

        xyz = <form>
            <FormControl id="email" isRequired >
                <FormLabel>Email address</FormLabel>
                <Input type="email" />
                <FormHelperText>We'll never share your email.</FormHelperText>
            </FormControl>

            <FormControl id="first-name" isRequired>
                <FormLabel>First name</FormLabel>
                <Input placeholder="First name" />
            </FormControl>

            <FormControl as="fieldset" isRequired >
                <FormLabel as="legend">Favorite Naruto Character</FormLabel>
                <RadioGroup defaultValue="Itachi">
                    <HStack spacing="24px">
                        <Radio value="Sasuke">User</Radio>
                        <Radio value="Nagato">Volenteer</Radio>
                        <Radio value="Itachi">Organisations</Radio>
                    </HStack>
                </RadioGroup>
                <FormHelperText>Select only if you're a fan.</FormHelperText>
            </FormControl>

            <FormControl id="address" isRequired>
                <FormLabel>Address</FormLabel>
                <Input placeholder="Address" />
            </FormControl>

            <FormControl id="city" isRequired >
                <FormLabel>City</FormLabel>
                <Select placeholder="Select City">
                    <option>United Arab Emirates</option>
                    <option>Nigeria</option>
                </Select>
            </FormControl>


            <FormControl id="state" isRequired >
                <FormLabel>Country</FormLabel>
                <Select placeholder="Select State">
                    <option>United Arab Emirates</option>
                    <option>Nigeria</option>
                </Select>
            </FormControl>


        </form>;
    } else if (view == "VR") {


        xyz = <ViewRequest />
    } else {
        // profile edit 

        xyz = <ManageProfile />
    }



    return (



        <div className={styleDashboard.Dashboard}>


            <div className={styleDashboard.container2} >
                <Button onClick={() => { setView("CR"); localStorage.setItem("view", "CR"); }}> Create Resource </Button>
                <Button onClick={() => { setView("VR"); localStorage.setItem("view", "VR"); }}> View Request</Button>
                <Button onClick={() => { setView("MP"); localStorage.setItem("view", "MP"); }}> Manage profile</Button>
            </div>
            <div className={styleDashboard.container1}>
                {xyz}

            </div>
        </div>
    )
}

export default Dashboard;
