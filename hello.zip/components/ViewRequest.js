import React from 'react'
import styleViewRequest from '../styles/viewrequest.module.scss'

const ViewRequest = () => {

    return (
        <div className={styleViewRequest.viewrequest}>
            <div className={styleViewRequest.container}></div>
            <div className={styleViewRequest.container}></div>
            <div className={styleViewRequest.container}></div>
            <div className={styleViewRequest.container}></div>
            <div className={styleViewRequest.container}></div>
            <div className={styleViewRequest.container}></div>
        </div>
    )
}

export default ViewRequest;
