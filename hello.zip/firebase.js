import firebase from "firebase/app";
import "firebase/auth";
import "firebase/firestore";


firebase.apps.length
  ? firebase.app()
  : firebase.initializeApp({
    apiKey: "AIzaSyARG75FXaHUrp53c40cvqCyeGiayf9vbII",
    authDomain: "hackon-7fbb3.firebaseapp.com",
    projectId: "hackon-7fbb3",
    storageBucket: "hackon-7fbb3.appspot.com",
    messagingSenderId: "71778279254",
    appId: "1:71778279254:web:51ad9d4d7c8e31a51840f7",
    measurementId: "G-0BNBD6VZ8E"
  });

// firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE);


export default firebase;
